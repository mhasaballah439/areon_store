<?php return [
    'plugin' => [
        'name' => 'AdminAuth',
        'description' => ''
    ]
];